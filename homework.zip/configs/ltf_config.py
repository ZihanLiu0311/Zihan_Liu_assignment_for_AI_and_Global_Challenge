class LTFConfig():

    def __init__(self, pred_len) -> None:

        # exp
        self.embed = 'timeF'
        self.task_name = "long_term_forecast"
        self.features = 'M'
        self.target = 'OT'
        self.label_len = 0
        self.seasonal_patterns = "Monthly"
        self.batch_size = 32
        self.num_workers = 0
        self.freq = 'h'
        self.ex_chn = 4
        self.seq_len = 96
        self.pred_len = pred_len

        # model component
        self.activ = "gelu"
        self.norm = None
        self.use_last_norm = True

        # loss
        self.loss_fn = 'mse'
        self.lambda_acf = 0.5
        self.lambda_mse = 0.1
        self.acf_cutoff = 2

        # optim
        self.grad_clip_val = 1
        self.patience = 1
        self.lr = 1e-3
        self.lr_factor = 0.5
        self.optim = "adamw"
        self.weight_decay = 0.1




class Traffic_LTFConfig(LTFConfig):

    def __init__(self, pred_len) -> None:
        super().__init__(pred_len)
        self.name = "traffic"
        self.data = "custom"
        self.root_path = "./dataset/"
        self.data_path = "traffic.csv"
        self.in_chn = 862
        self.out_chn = 862
        self.batch_size = 16

        self.drop = 0.5
        self.patch_sizes = [24, 12, 6, 1]
        self.hid_chn = 512
        self.hid_len = 512
        self.hid_pred = 512
        self.hid_pch = 512


