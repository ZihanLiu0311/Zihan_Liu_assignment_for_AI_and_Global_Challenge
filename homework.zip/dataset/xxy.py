import torch
import torch.nn as nn


class CustomLSTM(nn.Module):
    def __init__(self, input_size, hidden_size):
        super(CustomLSTM, self).__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size

        # Define the weight matrix and bias term
        self.W_ii = nn.Parameter(torch.Tensor(input_size, hidden_size))
        self.W_hi = nn.Parameter(torch.Tensor(hidden_size, hidden_size))
        self.b_i = nn.Parameter(torch.Tensor(hidden_size))

        self.W_if = nn.Parameter(torch.Tensor(input_size, hidden_size))
        self.W_hf = nn.Parameter(torch.Tensor(hidden_size, hidden_size))
        self.b_f = nn.Parameter(torch.Tensor(hidden_size))

        self.W_ig = nn.Parameter(torch.Tensor(input_size, hidden_size))
        self.W_hg = nn.Parameter(torch.Tensor(hidden_size, hidden_size))
        self.b_g = nn.Parameter(torch.Tensor(hidden_size))

        self.W_io = nn.Parameter(torch.Tensor(input_size, hidden_size))
        self.W_ho = nn.Parameter(torch.Tensor(hidden_size, hidden_size))
        self.b_o = nn.Parameter(torch.Tensor(hidden_size))

        self.init_weights()

    def init_weights(self):
        nn.init.kaiming_uniform_(self.W_ii, a=0.01)
        nn.init.kaiming_uniform_(self.W_hi, a=0.01)
        nn.init.constant_(self.b_i, 0)

        nn.init.kaiming_uniform_(self.W_if, a=0.01)
        nn.init.kaiming_uniform_(self.W_hf, a=0.01)
        nn.init.constant_(self.b_f, 0)

        nn.init.kaiming_uniform_(self.W_ig, a=0.01)
        nn.init.kaiming_uniform_(self.W_hg, a=0.01)
        nn.init.constant_(self.b_g, 0)

        nn.init.kaiming_uniform_(self.W_io, a=0.01)
        nn.init.kaiming_uniform_(self.W_ho, a=0.01)
        nn.init.constant_(self.b_o, 0)

    def forward(self, x, init_states=None):
        seq_length, batch_size, _ = x.size()
        hidden_seq = []

        if init_states is None:
            h_t, c_t = torch.zeros(batch_size, self.hidden_size).to(x.device), torch.zeros(batch_size,
                                                                                           self.hidden_size).to(
                x.device)
        else:
            h_t, c_t = init_states

        for t in range(seq_length):
            x_t = x[t, :, :]

            i_t = torch.sigmoid(torch.mm(x_t, self.W_ii) + torch.mm(h_t, self.W_hi) + self.b_i)
            f_t = torch.sigmoid(torch.mm(x_t, self.W_if) + torch.mm(h_t, self.W_hf) + self.b_f)
            g_t = torch.tanh(torch.mm(x_t, self.W_ig) + torch.mm(h_t, self.W_hg) + self.b_g)
            o_t = torch.sigmoid(torch.mm(x_t, self.W_io) + torch.mm(h_t, self.W_ho) + self.b_o)

            c_t = f_t * c_t + i_t * g_t
            h_t = o_t * torch.tanh(c_t)

            hidden_seq.append(h_t.unsqueeze(0))

        hidden_seq = torch.cat(hidden_seq, dim=0)
        return hidden_seq, (h_t, c_t)


# Example usage.
input_size = 10
hidden_size = 10
seq_length = 5
batch_size = 3

# create sample model
lstm = CustomLSTM(input_size, hidden_size)

# Create example input tensors
input_data = torch.randn(seq_length, batch_size, input_size)

# Forward propagation.
output, (h_n, c_n) = lstm(input_data)
print("Output shape:", output.shape)
print("Final hidden state shape:", h_n.shape)
print("Final cell state shape:", c_n.shape)
