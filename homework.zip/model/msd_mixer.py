import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange, reduce
from einops.layers.torch import Rearrange
from timm.models.layers import DropPath
from .utils import get_activation
import math
import numpy as np


class Attn_PatchLevel(nn.Module):
    def __init__(self, in_chn, change_chn, d_model, dropout=0.1):
        super(Attn_PatchLevel, self).__init__()
        self.query_projection = nn.Linear(in_chn, d_model)
        self.d_model = d_model
        self.kv_projection = nn.Linear(in_chn, d_model)

        self.out_projection = nn.Linear(d_model, 1)
        self.dropout = nn.Dropout(dropout)
        self.linear = nn.Linear(in_chn, change_chn)
        self.change_chn = change_chn
        self.norm = nn.BatchNorm1d(96)
        self.in_chn = in_chn
    def forward(self, x, mask='Diag'):
        #print(x.size())
        queries, keys, values = x, x, x
        B, C, L = queries.shape
        _, S, _ = keys.shape
        queries = queries.transpose(1, 2).unsqueeze(-1).expand(B, L, C, C)
        keys = keys.transpose(1, 2).unsqueeze(-1).expand(B, L, S, S)
        values = values.unsqueeze(-1).transpose(1, 2).expand(B, L, S, S)
        

        scale = 1. / math.sqrt(self.d_model)

        queries = self.query_projection(queries)
        keys = self.kv_projection(keys)
        values = self.kv_projection(values)

        scores = torch.einsum("bvpd,bvsd->bvps", queries, keys)  # [B V P P]

        attn = self.dropout(torch.softmax(scale * scores, dim=-1))  # [B V P P]
        out = torch.einsum("bvps,bvsd->bvpd", attn, values)  # [B V P D]

        out = self.linear(self.out_projection(out).squeeze(-1)).transpose(1, 2) + x[:,:self.change_chn,:]
        return out  # [B V P D]



class CustomLSTM(nn.Module):
    def __init__(self, input_size, hidden_size):
        super(CustomLSTM, self).__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size

        # Define the weight matrix and bias term.
        self.W_ii = nn.Parameter(torch.Tensor(input_size, hidden_size))
        self.W_hi = nn.Parameter(torch.Tensor(hidden_size, hidden_size))
        self.b_i = nn.Parameter(torch.Tensor(hidden_size))

        self.W_if = nn.Parameter(torch.Tensor(input_size, hidden_size))
        self.W_hf = nn.Parameter(torch.Tensor(hidden_size, hidden_size))
        self.b_f = nn.Parameter(torch.Tensor(hidden_size))

        self.W_ig = nn.Parameter(torch.Tensor(input_size, hidden_size))
        self.W_hg = nn.Parameter(torch.Tensor(hidden_size, hidden_size))
        self.b_g = nn.Parameter(torch.Tensor(hidden_size))

        self.W_io = nn.Parameter(torch.Tensor(input_size, hidden_size))
        self.W_ho = nn.Parameter(torch.Tensor(hidden_size, hidden_size))
        self.b_o = nn.Parameter(torch.Tensor(hidden_size))

        self.init_weights()

    def init_weights(self):
        nn.init.kaiming_uniform_(self.W_ii, a=0.01)
        nn.init.kaiming_uniform_(self.W_hi, a=0.01)
        nn.init.constant_(self.b_i, 0)

        nn.init.kaiming_uniform_(self.W_if, a=0.01)
        nn.init.kaiming_uniform_(self.W_hf, a=0.01)
        nn.init.constant_(self.b_f, 0)

        nn.init.kaiming_uniform_(self.W_ig, a=0.01)
        nn.init.kaiming_uniform_(self.W_hg, a=0.01)
        nn.init.constant_(self.b_g, 0)

        nn.init.kaiming_uniform_(self.W_io, a=0.01)
        nn.init.kaiming_uniform_(self.W_ho, a=0.01)
        nn.init.constant_(self.b_o, 0)

    def forward(self, x, init_states=None):
        seq_length, batch_size, _ = x.size()
        hidden_seq = []

        if init_states is None:
            h_t, c_t = torch.zeros(batch_size, self.hidden_size).to(x.device), torch.zeros(batch_size,
                                                                                           self.hidden_size).to(
                x.device)
        else:
            h_t, c_t = init_states

        for t in range(seq_length):
            x_t = x[t, :, :]

            i_t = torch.sigmoid(torch.mm(x_t, self.W_ii) + torch.mm(h_t, self.W_hi) + self.b_i)
            f_t = torch.sigmoid(torch.mm(x_t, self.W_if) + torch.mm(h_t, self.W_hf) + self.b_f)
            g_t = torch.tanh(torch.mm(x_t, self.W_ig) + torch.mm(h_t, self.W_hg) + self.b_g)
            o_t = torch.sigmoid(torch.mm(x_t, self.W_io) + torch.mm(h_t, self.W_ho) + self.b_o)

            c_t = f_t * c_t + i_t * g_t
            h_t = o_t * torch.tanh(c_t)

            hidden_seq.append(h_t.unsqueeze(0))

        hidden_seq = torch.cat(hidden_seq, dim=0)
        return hidden_seq


class MLPBlock(nn.Module):

    def __init__(
        self,
        dim,
        in_features: int,
        hid_features: int,
        out_features: int,
        activ="gelu",
        drop: float = 0.0,
        jump_conn='trunc',
    ):
        super().__init__()
        self.dim = dim
        self.out_features = out_features
        self.net = nn.Sequential(
            nn.Linear(in_features, hid_features),
            get_activation(activ),
            nn.Linear(hid_features, out_features),
            DropPath(drop))
        if jump_conn == "trunc":
            self.jump_net = nn.Identity()
        elif jump_conn == 'proj':
            self.jump_net = nn.Linear(in_features, out_features)
        else:
            raise ValueError(f"jump_conn:{jump_conn}")

    def forward(self, x):
        x = torch.transpose(x, self.dim, -1)
        x = self.jump_net(x)[..., :self.out_features] + self.net(x)
        x = torch.transpose(x, self.dim, -1)
        return x


class PatchEncoder(nn.Module):

    def __init__(
        self,
        in_len: int,
        hid_len: int,
        in_chn: int,
        hid_chn: int,
        out_chn,
        patch_size: int,
        hid_pch: int,
        norm=None,
        activ="gelu",
        drop: float = 0.0,
    ) -> None:
        super().__init__()
        self.net = nn.Sequential()
        channel_wise_mlp = MLPBlock(1, in_chn, hid_chn, out_chn, activ, drop)
        inter_patch_mlp = MLPBlock(2, in_len // patch_size, hid_len, in_len // patch_size, activ,
                         drop)

        if norm == 'bn':
            norm_class = nn.BatchNorm2d
        elif norm == 'in':
            norm_class = nn.InstanceNorm2d
        else:
            norm_class = nn.Identity
        linear = nn.Linear(patch_size, 1)
        intra_patch_mlp = MLPBlock(3, patch_size, hid_pch, patch_size, activ, drop)
        att_patch = Attn_PatchLevel(in_chn, out_chn, hid_pch, dropout = drop)
        self.mylinear = nn.Linear(hid_len, in_len)
        self.mylstm = CustomLSTM(in_len, hid_len)

        self.net.append(self.mylstm)
        self.net.append(self.mylinear)
        self.net.append(norm_class(in_chn))
        #self.net.append(channel_wise_mlp)
        #self.net.append(norm_class(in_chn))


    def forward(self, x):
        # b,c,l
        return self.net(x)


class PatchDecoder(nn.Module):

    def __init__(
        self,
        in_len: int,
        hid_len: int,
        in_chn: int,
        hid_chn: int,
        out_chn,
        patch_size: int,
        hid_pch: int,
        norm=None,
        activ="gelu",
        drop: float = 0.0,
    ) -> None:
        super().__init__()
        self.net = nn.Sequential()
        inter_patch_mlp = MLPBlock(2, in_len // patch_size, hid_len, in_len // patch_size, activ,
                         drop)
        channel_wise_mlp = MLPBlock(1, in_chn, hid_chn, out_chn, activ, drop)

        if norm == 'bn':
            norm_class = nn.BatchNorm2d
        elif norm == 'in':
            norm_class = nn.InstanceNorm2d
        else:
            norm_class = nn.Identity
        linear = nn.Linear(1, patch_size)
        intra_patch_mlp = MLPBlock(3, patch_size, hid_pch, patch_size, activ, drop)
        self.net.append(Rearrange("b c l1 -> b c l1 1"))
        self.net.append(linear)
        self.net.append(norm_class(in_chn))
        self.net.append(intra_patch_mlp)
        self.net.append(norm_class(in_chn))
        self.net.append(inter_patch_mlp)
        self.net.append(norm_class(in_chn))
        self.net.append(channel_wise_mlp)
        self.net.append(Rearrange("b c l1 l2 -> b c (l1 l2)"))

    def forward(self, x):
        # b,c,l
        return self.net(x)


class PredictionHead(nn.Module):

    def __init__(self,
                 in_len,
                 out_len,
                 hid_len,
                 in_chn,
                 out_chn,
                 hid_chn,
                 activ,
                 drop=0.0) -> None:
        super().__init__()
        self.net = nn.Sequential()
        if in_chn != out_chn:
            c_jump_conn = "proj"
        else:
            c_jump_conn = "trunc"
        self.net.append(
            MLPBlock(1,
                in_chn,
                hid_chn,
                out_chn,
                activ=activ,
                drop=drop,
                jump_conn=c_jump_conn))
        self.net.append(
            MLPBlock(2,
                in_len,
                hid_len,
                out_len,
                activ=activ,
                drop=drop,
                jump_conn='proj'))

    def forward(self, x):
        return self.net(x)


class MSDMixer(nn.Module):

    def __init__(self,
                 in_len,
                 out_len,
                 in_chn,
                 ex_chn,
                 out_chn,
                 patch_sizes,
                 hid_len,
                 hid_chn,
                 hid_pch,
                 hid_pred,
                 norm,
                 last_norm,
                 activ,
                 drop,
                 reduction="sum") -> None:
        super().__init__()
        self.in_len = in_len
        self.out_len = out_len
        self.in_chn = in_chn
        self.out_chn = out_chn
        self.last_norm = last_norm
        self.reduction = reduction
        self.patch_encoders = nn.ModuleList()
        self.patch_decoders = nn.ModuleList()
        self.pred_heads = nn.ModuleList()
        self.patch_sizes = patch_sizes
        self.att_patch = Attn_PatchLevel(in_chn, out_chn, hid_pch, dropout = drop)
        self.mylinear = nn.Linear(hid_len, in_len)
        self.mylstm = CustomLSTM(in_len, hid_len)

        all_chn = in_chn 

        self.encoder = PatchEncoder(in_len, hid_len, all_chn, hid_chn, in_chn, 2, hid_pch, norm, activ, drop)
        #channel_wise_mlp = MLPBlock(1, in_chn, hid_chn, out_chn, activ, drop)
        
        #LSTM
        #self.net = nn.Sequential()
        #self.net.append(channel_wise_mlp)
        #self.net.append(self.mylstm)
        #self.net.append(self.mylinear)
        

        self.paddings = []
        #all_chn = in_chn + ex_chn
        for i, patch_size in enumerate(patch_sizes):
            res = in_len % patch_size
            padding = (patch_size - res) % patch_size
            self.paddings.append(padding)
            padded_len = in_len + padding
            self.patch_encoders.append(
                PatchEncoder(padded_len, hid_len, all_chn, hid_chn,
                          in_chn, patch_size, hid_pch, norm, activ, drop))
            self.patch_decoders.append(
                PatchDecoder(padded_len, hid_len, in_chn, hid_chn, in_chn,
                        patch_size, hid_pch, norm, activ, drop))
            if out_len != 0 and out_chn != 0:
                self.pred_heads.append(
                    PredictionHead(padded_len // patch_size, out_len, hid_pred,
                                    in_chn, out_chn, hid_chn, activ, drop))
            else:
                self.pred_heads.append(nn.Identity())

            self.mypred_heads = PredictionHead(in_len, out_len, hid_pred, in_chn, out_chn, hid_chn, activ, drop)


    def forward(self, x, x_mark=None, x_mask=None):
        x = rearrange(x, "b l c -> b c l")
        if self.last_norm:
            x_last = x[:, :, [-1]].detach()
            x = x - x_last


        for l in range(1):
            y_pred = self.encoder(x)
            x = y_pred
        y_pred = self.mypred_heads(y_pred)
        if self.last_norm and self.out_chn == self.in_chn:
            y_pred += x_last
        y_pred = rearrange(y_pred, "b c l -> b l c")

        return y_pred, x

